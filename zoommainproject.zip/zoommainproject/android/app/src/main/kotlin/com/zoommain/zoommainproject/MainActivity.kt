package com.zoommain.zoommainproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
