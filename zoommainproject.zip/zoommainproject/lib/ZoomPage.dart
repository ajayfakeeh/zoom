// import 'package:flutter/material.dart';
// import 'package:zoom_module/zoom_module.dart';
//
// class ZoomPage extends StatefulWidget {
//   const ZoomPage({Key? key}) : super(key: key);
//
//   @override
//   State<ZoomPage> createState() => _ZoomPageState();
// }
//
// class _ZoomPageState extends State<ZoomPage> {
//   final ZoomModule _zoomModule = ZoomModule();
//   bool _isInSession = false;
//   Widget? _zoomView;
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeZoom();
//   }
//
//   Future<void> _initializeZoom() async {
//     await _zoomModule.initialize( sdkKey: "lDH5eS-EQ8CtrenG_3h-Qg",
//       sdkSecret: "johztfiUeCBmuouMJOWafvSnrb1JLCtlJa5p");
//   }
//
//   Future<void> _joinMeeting() async {
//     // Define your meeting details
//     print("calling.......");
//
//
//     final meetingDetails = {
//       'sessionName': 'Your Meeting Name',
//       'displayName': 'Your Display Name',
//       'password': 'Meeting Password', // Optional
//     };
//
//     final zoomView = await _zoomModule.joinSession(
//       sessionName: meetingDetails['sessionName'],
//       displayName: meetingDetails['displayName'],
//       password: meetingDetails['password'],
//       audioOn: true,
//       videoOn: true,
//       onSessionEnded: () {
//         setState(() {
//           _isInSession = false;
//           _zoomView = null;
//         });
//       },
//     );
//
//     setState(() {
//       _isInSession = true;
//       _zoomView = zoomView;
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     if (_isInSession && _zoomView != null) {
//       return _zoomView!;
//     }
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Zoom Integration'),
//       ),
//       body: Center(
//         child: ElevatedButton(
//           onPressed: _joinMeeting,
//           child: const Text('Join Zoom Meeting'),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zoom_module/zoom_module.dart';

class ZoomMeetingScreen extends StatefulWidget {
  const ZoomMeetingScreen({Key? key}) : super(key: key);

  @override
  State<ZoomMeetingScreen> createState() => _ZoomMeetingScreenState();
}

class _ZoomMeetingScreenState extends State<ZoomMeetingScreen> {
  final ZoomModule _zoomModule = ZoomModule();
  bool _isLoading = false;
  String _status = '';
  Widget? _meetingView;

  @override
  void initState() {
    super.initState();
    _setupEventHandlers();
    _initializeZoom();
  }

  void _setupEventHandlers() {
    _zoomModule.setEventCallbacks(
      onUserJoined: (data) {
        setState(() {
          _status = 'User joined: ${data['userName']}';
        });
      },
      onUserLeft: (data) {
        setState(() {
          _status = 'User left: ${data['userName']}';
        });
      },
      onError: (data) {
        setState(() {
          _status = 'Error: ${data['errorMessage']}';
        });
      },
    );
  }

  Future<void> _initializeZoom() async {
    setState(() {
      _isLoading = true;
      _status = 'Initializing...';
    });

    try {
      await _zoomModule.initialize(
        sdkKey: 'lDH5eS-EQ8CtrenG_3h-Qg',
        sdkSecret: 'johztfiUeCBmuouMJOWafvSnrb1JLCtlJa5p',
      );

      setState(() {
        _isLoading = false;
        _status = 'Ready to join';
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _status = 'Error: $e';
      });
    }
  }

  Future<void> _joinMeeting() async {
    setState(() {
      _isLoading = true;
      _status = 'Joining meeting...';
    });

    try {
      final view = await _zoomModule.joinSession(
        sessionName: 'Your Meeting Name',
        displayName: 'Your Name',
        onSessionEnded: () {
          setState(() {
            _meetingView = null;
            _status = 'Session ended';
          });
        },
      );

      setState(() {
        _meetingView = view;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _status = 'Error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_meetingView != null) {
      return _meetingView!;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Zoom Meeting')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_status),
            const SizedBox(height: 20),
            if (_isLoading)
              const CircularProgressIndicator()
            else
              ElevatedButton(
                onPressed: _joinMeeting,
                child: const Text('Join Meeting'),
              ),
          ],
        ),
      ),
    );
  }
}
